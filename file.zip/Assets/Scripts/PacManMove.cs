﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PacManMove : MonoBehaviour
{
    public Direction CurrentDirection;
    float distance;
    float distanceToMove;
    public float Speed = 1f;
    List<Tween> Tweens = new List<Tween>();
    int tweenIndex;
    private void Start()
    {
        Tweens.Add(new Tween(Direction.Up, 72f));
        Tweens.Add(new Tween(Direction.Left, 90f));
        Tweens.Add(new Tween(Direction.Down, 72f));
        Tweens.Add(new Tween(Direction.Right, 90f));
        GetComponent<Animator>().SetBool("IsMoving", true);
        CurrentDirection = Tweens[tweenIndex].MoveDirection;
        distanceToMove = Tweens[tweenIndex].MoveDistance;
        SetDirection();
    }
    void FixedUpdate()
    {
        if (distance >= distanceToMove)
        {
            distance = 0;
            NextTween();
        }
        distance += Speed * Time.fixedDeltaTime;
        transform.GetComponent<RectTransform>().anchoredPosition += Speed * MoveDirection() * Time.fixedDeltaTime;
    }
    void NextTween()
    {
        if (tweenIndex == Tweens.Count-1)
        {
            tweenIndex = 0;
        }
        else
        {
            tweenIndex++;
        }
        CurrentDirection = Tweens[tweenIndex].MoveDirection;
        distanceToMove = Tweens[tweenIndex].MoveDistance;
        SetDirection();
    }
    void SetDirection()
    {
        switch (CurrentDirection)
        {
            case Direction.Right:
                transform.rotation = Quaternion.Euler(new Vector3(0, 180, 0));
                break;
            case Direction.Up:
                transform.rotation = Quaternion.Euler(new Vector3(0, 0, -90));
                break;
            case Direction.Left:
                transform.rotation = Quaternion.identity;
                break;
            case Direction.Down:
                transform.rotation = Quaternion.Euler(new Vector3(0, 0, 90));
                break;
            default:
                break;
        }
    }
    Vector2 MoveDirection()
    {
        switch (CurrentDirection)
        {
            case Direction.Right:
                return Vector2.right;
            case Direction.Up:
                return Vector2.up;
            case Direction.Left:
                return Vector2.left;
            case Direction.Down:
                return Vector2.down;
            default:
                return Vector2.right;
        }
    }
}
public class Tween
{
    public Direction MoveDirection;
    public float MoveDistance;
    public Tween(Direction _MoveDirection, float _MoveDistance)
    {
        MoveDirection = _MoveDirection;
        MoveDistance = _MoveDistance;
    }
}

