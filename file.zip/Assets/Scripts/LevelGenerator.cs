﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class LevelGenerator : MonoBehaviour
{
    int[,] LevelMap = new int[30, 28]
         {
            {1,2,2,2,2,2,2,2,2,2,2,2,2,7,7,2,2,2,2,2,2,2,2,2,2,2,2,1},
            {2,5,5,5,5,5,5,5,5,5,5,5,5,4,4,5,5,5,5,5,5,5,5,5,5,5,5,2},
            {2,5,3,4,4,3,5,3,4,4,4,3,5,4,4,5,3,4,4,4,3,5,3,4,4,3,5,2},
            {2,6,4,0,0,4,5,4,0,0,0,4,5,4,4,5,4,0,0,0,4,5,4,0,0,4,6,2},
            {2,5,3,4,4,3,5,3,4,4,4,3,5,3,3,5,3,4,4,4,3,5,3,4,4,3,5,2},
            {2,5,5,5,5,5,8,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,2},
            {2,5,3,4,4,3,5,3,3,5,3,4,4,4,4,4,4,3,5,3,3,5,3,4,4,3,5,2},
            {2,5,3,4,4,3,5,4,4,5,3,4,4,3,3,4,4,3,5,4,4,5,3,4,4,3,5,2},
            {2,5,5,5,5,5,5,4,4,5,5,5,5,4,4,5,5,5,5,4,4,5,5,5,5,5,5,2},
            {1,2,2,2,2,1,5,4,3,4,4,3,0,4,4,0,3,4,4,3,4,5,1,2,2,2,2,1},
            {0,0,0,0,0,2,5,4,3,4,4,3,0,3,3,0,3,4,4,3,4,5,2,0,0,0,0,0},
            {0,0,0,0,0,2,5,4,4,0,0,0,0,0,0,0,0,0,0,4,4,5,2,0,0,0,0,0},
            {0,0,0,0,0,2,5,4,4,0,3,4,4,0,0,4,4,3,0,4,4,5,2,0,0,0,0,0},
            {2,2,2,2,2,1,5,3,3,0,4,0,0,0,0,0,0,4,0,3,3,5,1,2,2,2,2,2},
            {0,0,0,0,0,0,5,0,0,0,4,0,0,0,0,0,0,4,0,0,0,5,0,0,0,0,0,0},
            {0,0,0,0,0,0,5,0,0,0,4,0,0,0,0,0,0,4,0,0,0,5,0,0,0,0,0,0},
            {2,2,2,2,2,1,5,3,3,0,4,0,0,0,0,0,0,4,0,3,3,5,1,2,2,2,2,2},
            {0,0,0,0,0,2,5,4,4,0,3,4,4,0,0,4,4,3,0,4,4,5,2,0,0,0,0,0},
            {0,0,0,0,0,2,5,4,4,0,0,0,0,0,0,0,0,0,0,4,4,5,2,0,0,0,0,0},
            {0,0,0,0,0,2,5,4,3,4,4,3,0,3,3,0,3,4,4,3,4,5,2,0,0,0,0,0},
            {1,2,2,2,2,1,5,4,3,4,4,3,0,4,4,0,3,4,4,3,4,5,1,2,2,2,2,1},
            {2,5,5,5,5,5,5,4,4,5,5,5,5,4,4,5,5,5,5,4,4,5,5,5,5,5,5,2},
            {2,5,3,4,4,3,5,4,4,5,3,4,4,3,3,4,4,3,5,4,4,5,3,4,4,3,5,2},
            {2,5,3,4,4,3,5,3,3,5,3,4,4,4,4,4,4,3,5,3,3,5,3,4,4,3,5,2},
            {2,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,2},
            {2,5,3,4,4,3,5,3,4,4,4,3,5,3,3,5,3,4,4,4,3,5,3,4,4,3,5,2},
            {2,6,4,0,0,4,5,4,0,0,0,4,5,4,4,5,4,0,0,0,4,5,4,0,0,4,6,2},
            {2,5,3,4,4,3,5,3,4,4,4,3,5,4,4,5,3,4,4,4,3,5,3,4,4,3,5,2},
            {2,5,5,5,5,5,5,5,5,5,5,5,5,4,4,5,5,5,5,5,5,5,5,5,5,5,5,2},
            {1,2,2,2,2,2,2,2,2,2,2,2,2,7,7,2,2,2,2,2,2,2,2,2,2,2,2,1},
         };

    MapUnitData[,] WholeMapUnitData;

    public Image MapBG;
    public List<GameObject> MapUnitPrefabs = new List<GameObject>();

    void Awake()
    {
        GenerateMap();
    }


    //left up map
    private void GenerateMap()
    {
        int rows = LevelMap.GetLength(0);
        int columns = LevelMap.GetLength(1);
        WholeMapUnitData = new MapUnitData[rows, columns];
        for (int r = 0; r < rows; r++)
        {
            for (int c = 0; c < columns; c++)
            {
                Direction mapUnitDir = Direction.Right;
                MapUnitType tempMapUnitType = (MapUnitType)LevelMap[r, c];
                bool ExistLeftJunction = false;
                bool ExistUpJunction = false;
                switch (tempMapUnitType)
                {
                    case MapUnitType.OutsideCorner:
                    case MapUnitType.InsideCorner:
                        //Exist LeftJunction
                        if (c > 0 && WholeMapUnitData[r, c - 1].Junctions.Count > 0 && WholeMapUnitData[r, c - 1].Junctions.Contains(Direction.Right))
                        {
                            ExistLeftJunction = true;
                        }
                        //Exit UpJunction
                        if (r > 0 && WholeMapUnitData[r - 1, c].Junctions.Count > 0 && WholeMapUnitData[r - 1, c].Junctions.Contains(Direction.Down))
                        {
                            ExistUpJunction = true;
                        }
                        if (ExistLeftJunction && ExistUpJunction)
                        {
                            mapUnitDir = Direction.Left;
                        }
                        else if (ExistLeftJunction && !ExistUpJunction)
                        {
                            mapUnitDir = Direction.Down;
                        }
                        else if (!ExistLeftJunction && !ExistUpJunction)
                        {
                            mapUnitDir = Direction.Right;
                        }
                        else
                        {
                            mapUnitDir = Direction.Up;
                        }
                        break;
                    case MapUnitType.OutsideWall:
                        //Exist LeftJunction
                        if (c > 0 && WholeMapUnitData[r, c - 1].Junctions.Count > 0 && WholeMapUnitData[r, c - 1].Junctions.Contains(Direction.Right))
                        {
                            if (WholeMapUnitData[r, c - 1].UnitType.Equals(MapUnitType.OutsideWall))
                            {
                                mapUnitDir = WholeMapUnitData[r, c - 1].UnitDirection;
                            }
                            else if (WholeMapUnitData[r, c - 1].UnitType.Equals(MapUnitType.OutsideCorner))
                            {
                                if (WholeMapUnitData[r, c - 1].UnitDirection.Equals(Direction.Right))
                                {
                                    mapUnitDir = Direction.Right;
                                }
                                else
                                {
                                    mapUnitDir = Direction.Left;
                                }
                            }
                            ExistLeftJunction = true;
                        }
                        //Exit UpJunction
                        else if (r > 0 && WholeMapUnitData[r - 1, c].Junctions.Count > 0 && WholeMapUnitData[r - 1, c].Junctions.Contains(Direction.Down))
                        {
                            if (WholeMapUnitData[r - 1, c].UnitType.Equals(MapUnitType.OutsideWall))
                            {
                                mapUnitDir = WholeMapUnitData[r - 1, c].UnitDirection;
                            }
                            else if (WholeMapUnitData[r - 1, c].UnitType.Equals(MapUnitType.OutsideCorner))
                            {
                                if (WholeMapUnitData[r - 1, c].UnitDirection.Equals(Direction.Right))
                                {
                                    mapUnitDir = Direction.Up;
                                }
                                else
                                {
                                    mapUnitDir = Direction.Down;
                                }
                            }
                            ExistUpJunction = true;
                        }
                        else if (c == 0)
                        {
                            if (WholeMapUnitData[r - 1, c].UnitType.Equals(MapUnitType.OutsideWall))
                            {
                                mapUnitDir = WholeMapUnitData[r - 1, c].UnitDirection;
                            }
                            else if (WholeMapUnitData[r - 1, c].UnitType.Equals(MapUnitType.OutsideCorner))
                            {
                                mapUnitDir = Direction.Up;
                            }
                            else
                            {
                                mapUnitDir = Direction.Right;
                            }
                        }
                        break;
                    case MapUnitType.InsideWall:
                        //Exit UpJunction
                        if (r > 0 && WholeMapUnitData[r - 1, c].Junctions.Count > 0 && WholeMapUnitData[r - 1, c].Junctions.Contains(Direction.Down))
                        {
                            if (WholeMapUnitData[r - 1, c].UnitType.Equals(MapUnitType.InsideWall))
                            {
                                mapUnitDir = WholeMapUnitData[r - 1, c].UnitDirection;
                            }
                            else if (WholeMapUnitData[r - 1, c].UnitType.Equals(MapUnitType.InsideCorner))
                            {
                                if (WholeMapUnitData[r - 1, c].UnitDirection.Equals(Direction.Right))
                                {
                                    mapUnitDir = Direction.Up;
                                }
                                else
                                {
                                    mapUnitDir = Direction.Down;
                                }
                            }
                            else if (WholeMapUnitData[r - 1, c].UnitType.Equals(MapUnitType.Junction))
                            {
                                mapUnitDir = Direction.Up;
                            }
                            ExistLeftJunction = true;
                        }
                        //Exist LeftJunction
                        else if (c > 0 && WholeMapUnitData[r, c - 1].Junctions.Count > 0 && WholeMapUnitData[r, c - 1].Junctions.Contains(Direction.Right))
                        {
                            if (WholeMapUnitData[r, c - 1].UnitType.Equals(MapUnitType.InsideWall))
                            {
                                mapUnitDir = WholeMapUnitData[r, c - 1].UnitDirection;
                            }
                            else if (WholeMapUnitData[r, c - 1].UnitType.Equals(MapUnitType.InsideCorner))
                            {
                                if (WholeMapUnitData[r, c - 1].UnitDirection.Equals(Direction.Right))
                                {
                                    mapUnitDir = Direction.Right;
                                }
                                else
                                {
                                    mapUnitDir = Direction.Left;
                                }
                            }
                            ExistUpJunction = true;
                        }
                        break;
                    case MapUnitType.Junction:
                        //Exist LeftJunction
                        if (c > 0 && WholeMapUnitData[r, c - 1].Junctions.Count > 0 && WholeMapUnitData[r, c - 1].Junctions.Contains(Direction.Right))
                        {
                            if (WholeMapUnitData[r, c - 1].UnitType.Equals(MapUnitType.OutsideWall))
                            {
                                if (r == 0)
                                {
                                    mapUnitDir = Direction.Right;
                                }
                                else
                                {
                                    mapUnitDir = Direction.Down;
                                }
                            }
                            else if (WholeMapUnitData[r, c - 1].UnitType.Equals(MapUnitType.Junction))
                            {
                                if (r == 0)
                                {
                                    mapUnitDir = Direction.Up;
                                }
                                else
                                {
                                    mapUnitDir = Direction.Left;
                                }
                            }
                            ExistLeftJunction = true;
                        }
                        break;
                    case MapUnitType.Empty:
                    case MapUnitType.NormalPellet:
                    case MapUnitType.SpecialPellet:
                    case MapUnitType.PacMan:
                    case MapUnitType.Catcher:
                    default:
                        break;
                }
                WholeMapUnitData[r, c] = new MapUnitData((MapUnitType)LevelMap[r, c], mapUnitDir);
                GameObject go = Instantiate(MapUnitPrefabs[LevelMap[r, c]], MapBG.transform);
                go.GetComponent<RectTransform>().anchoredPosition = new Vector2(-MapBG.GetComponent<RectTransform>().sizeDelta.x / 2f + 9 + c * 18, MapBG.GetComponent<RectTransform>().sizeDelta.y / 2f - 9 - r * 18);
                go.AddComponent<MapUnitItem>().MapUnitData = WholeMapUnitData[r, c];
                go.GetComponent<MapUnitItem>().SetRotation(mapUnitDir);
            }
        }
    }
}

public enum MapUnitType
{
    Empty,
    OutsideCorner,
    OutsideWall,
    InsideCorner,
    InsideWall,
    NormalPellet,
    SpecialPellet,
    Junction,
    PacMan,
    Catcher,
}


public enum Direction
{
    Right,
    Up,
    Left,
    Down,
}
