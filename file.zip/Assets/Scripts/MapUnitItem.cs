﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class MapUnitItem : MonoBehaviour
{
    public MapUnitData MapUnitData;
    public void SetRotation(Direction _mapUnitDirection)
    {
        if (MapUnitData.UnitType.Equals(MapUnitType.Junction))
        {
            switch (_mapUnitDirection)
            {
                case Direction.Right:
                    transform.localScale = Vector3.one;
                    break;
                case Direction.Up:
                    transform.localScale = new Vector3(-1, 1, 1);
                    break;
                case Direction.Left:
                    transform.localScale = new Vector3(-1, -1, 1);
                    break;
                case Direction.Down:
                    transform.localScale = new Vector3(1, -1, 1);
                    break;
                default:
                    break;
            }
        }
        else
        {
            switch (_mapUnitDirection)
            {
                case Direction.Right:
                    transform.rotation = Quaternion.identity;
                    break;
                case Direction.Up:
                    transform.rotation = Quaternion.Euler(new Vector3(0, 0, 90));
                    break;
                case Direction.Left:
                    transform.rotation = Quaternion.Euler(new Vector3(0, 0, 180));
                    break;
                case Direction.Down:
                    transform.rotation = Quaternion.Euler(new Vector3(0, 0, 270));
                    break;
                default:
                    break;
            }
        }
    }
}
[System.Serializable]
public class MapUnitData
{
    public MapUnitType UnitType;
    public Direction UnitDirection;
    public List<Direction> Junctions = new List<Direction>();
    public MapUnitData(MapUnitType _mapUnitType, Direction _direction)
    {
        UnitType = _mapUnitType;
        UnitDirection = _direction;
        switch (UnitType)
        {
            case MapUnitType.Empty:
            case MapUnitType.PacMan:
            case MapUnitType.Catcher:
            case MapUnitType.NormalPellet:
            case MapUnitType.SpecialPellet:
                break;
            case MapUnitType.OutsideCorner:
            case MapUnitType.InsideCorner:
                if (_direction.Equals(Direction.Right))
                {
                    Junctions.Add(Direction.Right);
                    Junctions.Add(Direction.Down);
                }
                else if (_direction.Equals(Direction.Up))
                {
                    Junctions.Add(Direction.Up);
                    Junctions.Add(Direction.Right);
                }
                else if (_direction.Equals(Direction.Left))
                {
                    Junctions.Add(Direction.Left);
                    Junctions.Add(Direction.Up);
                }
                else
                {
                    Junctions.Add(Direction.Down);
                    Junctions.Add(Direction.Left);
                }
                break;
            case MapUnitType.OutsideWall:
            case MapUnitType.InsideWall:
                if (_direction.Equals(Direction.Right) || _direction.Equals(Direction.Left))
                {
                    Junctions.Add(Direction.Right);
                    Junctions.Add(Direction.Left);
                }
                else
                {
                    Junctions.Add(Direction.Up);
                    Junctions.Add(Direction.Down);
                }
                break;
            case MapUnitType.Junction:
                if (_direction.Equals(Direction.Right))
                {
                    Junctions.Add(Direction.Left);
                    Junctions.Add(Direction.Right);
                    Junctions.Add(Direction.Down);
                }
                else if (_direction.Equals(Direction.Up))
                {
                    Junctions.Add(Direction.Left);
                    Junctions.Add(Direction.Right);
                    Junctions.Add(Direction.Down);
                }
                else if (_direction.Equals(Direction.Left))
                {
                    Junctions.Add(Direction.Left);
                    Junctions.Add(Direction.Right);
                    Junctions.Add(Direction.Up);
                }
                else
                {
                    Junctions.Add(Direction.Right);
                    Junctions.Add(Direction.Up);
                    Junctions.Add(Direction.Left);
                }
                break;
            default:
                break;
        }
    }
}
